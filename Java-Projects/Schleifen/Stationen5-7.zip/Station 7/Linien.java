import java.util.Scanner;

class Linien {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Geben Sie eine Zahl ein: ");
    int zahl = scanner.nextInt();
    String linie = "";
    int i = zahl;
    do{
      linie+="-";
      i--;
    } while (i > 0);
    i = zahl;
    do{
      linie+="+";
      i--;
    }while(i > 0);
    System.out.println(linie);
  }
  }
