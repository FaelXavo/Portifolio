import java.util.Scanner;

class Faktorial {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Geben Sie eine Zahl ein: ");
    final int ZAHL = scanner.nextInt();
    int ergebniss = 0;
    String zahlen = "";
    int i = 0;
    do{
      ergebniss += i;
      zahlen += i;
      if (i!= ZAHL) {
        zahlen += "+";
      }
      i++;
    } while(i <= ZAHL);
    zahlen+= "= ";
    System.out.println("\n" + zahlen + ergebniss);
  }
  }
