import java.util.Scanner;

class A3_1{
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    System.out.print("Geben Sie die Gr��e des Arrays ein: ");
    int x = s.nextInt();
    int[] array = new int[x];
    for (int i = 0; i < x; i++) {
      array[i] = i;
    }
    for (int i = 0; i < x; i++) {
      System.out.print(array[i]);
      if (i < x -1) {
        System.out.print(", ");
      } 
    }
    }
  }
