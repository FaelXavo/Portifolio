class A1_2{
  public static void main(String[] args) {
    int[] numbers = new int[15];
    for (int i = 0; i < 15; i++) {
      numbers[i] = i;
    } 
  }
}
