class A1_3{
  public static void main(String[] args) {
    int[] decrecent = new int[17];
    int j = 0;
    for (int i = 0; i < 17; i++) {
      decrecent[i] = 16 - i;
    }
  }
}
