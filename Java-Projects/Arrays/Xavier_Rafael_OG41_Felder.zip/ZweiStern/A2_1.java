import java.util.Scanner;
import java.util.Arrays;


class A2_1{
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int[] userNumbers = new int [5];
    System.out.println("Geben Sie 5 Werte ein: ");
    for (int i = 0; i < 5; i++){
      System.out.print((i+1) + ". zahl: ");
      userNumbers[i] = s.nextInt();
      }
    for (int zahl : userNumbers ) {
      System.out.print(zahl + ", ");
    } 
  }
}
