import java.util.Scanner;

class A2_2{
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    System.out.print("Geben Sie die Gr��e des Arrays ein: ");
    int x = s.nextInt();
    int[] array = new int[x];
    for (int i = 0; i < x; i++) {
      array[i] = i;
    }
    for (int zahl : array) {
      System.out.print(zahl + ", ");
    }
  }
}
